/*
 * ---------------------------------------------------------------
 *                 ESTRUCTURAS DE DATOS - EXAMEN FINAL
 * ---------------------------------------------------------------
 *                            Ejercicio 3
 * ---------------------------------------------------------------
 *
 * IMPORTANTE: Para realizar este ejercicio solo es necesario
 * modificar el código contenido entre las etiquetas <answer>
 * y </answer>. Toda modificación fuera de esas etiquetas no se
 * tendrá en cuenta para la corrección.
 *
 * ---------------------------------------------------------------
 */
 
 
//@ <answer>

// Manuel Montenegro Montes

//@ </answer>
 

//@ <answer>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdexcept>
#include <unordered_map>
#include <map>
#include <set>
//@ </answer>


using namespace std;

//@ <answer>

// Implementa los métodos pedidos dentro de la clase.
// No te olvides del coste de cada método.

class Ferrovistan {
public:


  // O(1)

  void nueva_linea(const string &nombre) {
  

    if (lineas.count(nombre)) {               // O(1)
      throw domain_error("Linea existente");
    }
    lineas.insert({nombre, {}});              // O(1)

  }
  

  // O(log L + log E), donde L es el número de líneas y E es el número de
  // estaciones.

  void nueva_estacion(const string &linea, const string &nombre, int posicion) {


    InfoLinea &il = buscar_linea(linea);    // O(1)
    if (estaciones.count(nombre) && estaciones.at(nombre).count(linea)) { // O(1) + O(log L)
      throw domain_error("Estacion duplicada en linea");
    }
    if (il.count(posicion)) { // O(log E)
      throw domain_error("Posicion ocupada");
    }
    il.insert({posicion, nombre});        // O(log E)
    estaciones[nombre][linea] = posicion; // O(log L)

  }
  

  // O(L * log E), donde L es el número de líneas y E es el número de
  // estaciones.

  void eliminar_estacion(const string &estacion) {


    InfoEstacion &ip = buscar_estacion(estacion);   // O(1)
    for (auto [linea, pos] : ip) {  // L veces ==> O(L * log E)    
      lineas[linea].erase(pos);     // O(log E)
    }
    
    estaciones.erase(estacion);   // O(1)

  }
  

  // O(L), donde L es el número de líneas

  vector<string> lineas_de(const string &estacion) const {


    const InfoEstacion &ip = buscar_estacion(estacion);   // O(1)
    vector<string> result;
    for (auto [linea, _] : ip) {    // L veces ==> O(L)
      result.push_back(linea);      // O(1)
    }
    return result;    

  }
  
  

  // O(log L + log E), donde L es el número de líneas y E es el número de
  // estaciones.

  string proxima_estacion(const string &linea, const string &estacion) const {


    const InfoLinea &il = buscar_linea(linea);            // O(1)
    const InfoEstacion &ie = buscar_estacion(estacion);   // O(1)

    auto itLinea = ie.find(linea);                        // O(log L)
    if (itLinea == ie.end()) {
      throw domain_error("Estacion no existente");
    }
    
    int pos = itLinea->second;
    
    auto itEstacion = il.find(pos);                       // O(log E)
    itEstacion++;                                         // O(1)
    if (itEstacion == il.end()) {
      throw domain_error("Fin de trayecto");
    }
    return itEstacion->second;

  }

private:

  // Implementación privada


  using InfoLinea = map<int, string>;
  using InfoEstacion = map<string, int>;


  // Para cada línea almacenamos un diccionario, que indica
  // en qué posición está cada estación.
  unordered_map<string, InfoLinea> lineas;

  // Para cada estación almacenamos un diccionario que indica,
  // para aquellas líneas en las que está, la posición.
  unordered_map<string, InfoEstacion> estaciones;
  
  InfoLinea &buscar_linea(const string &nombre) {
    auto it = lineas.find(nombre);      // O(1)
    if (it == lineas.end()) {
      throw domain_error("Linea no existente");
    } else {
      return it->second;
    }
  }

  const InfoLinea &buscar_linea(const string &nombre) const {
    auto it = lineas.find(nombre);      // O(1)
    if (it == lineas.end()) {
      throw domain_error("Linea no existente");
    } else {
      return it->second;
    }
  }

  InfoEstacion &buscar_estacion(const string &nombre) {
    auto it = estaciones.find(nombre);      // O(1)
    if (it == estaciones.end()) {
      throw domain_error("Estacion no existente");
    } else {
      return it->second;
    }
  }

  const InfoEstacion &buscar_estacion(const string &nombre) const {
    auto it = estaciones.find(nombre);      // O(1)
    if (it == estaciones.end()) {
      throw domain_error("Estacion no existente");
    } else {
      return it->second;
    }
  }

};



//---------------------------------------------------------------
// No modificar nada por debajo de esta línea
// -------------------------------------------------------------
//@ </answer>

bool tratar_caso() {
  Ferrovistan f;
  string operacion;
  cin >> operacion;
  
  if (cin.eof()) return false;
  
  while (operacion != "FIN") {
    try {
      if (operacion == "nueva_linea") {
        string nombre; cin >> nombre;
        f.nueva_linea(nombre);
      } else if (operacion == "nueva_estacion") {
        string linea; cin >> linea;
        string nombre; cin >> nombre;
        int posicion; cin >> posicion;
        f.nueva_estacion(linea, nombre, posicion);
      } else if (operacion == "eliminar_estacion") {
        string estacion; cin >> estacion;
        f.eliminar_estacion(estacion);
      } else if (operacion == "lineas_de") {
        string estacion; cin >> estacion;
        vector<string> lineas = f.lineas_de(estacion);
        cout << "Lineas de " << estacion << ":";
        for (const string &linea: lineas) {
          cout << " " << linea;
        }
        cout << "\n";
      } else if (operacion == "proxima_estacion") {
        string linea; cin >> linea;
        string estacion; cin >> estacion;
        string proxima = f.proxima_estacion(linea, estacion);
        cout << proxima << "\n";
      }
    } catch (exception &e) {
      cout << "ERROR: " << e.what() << "\n";
    }
    cin >> operacion;
  }  
  cout << "---\n";
  return true;
}


int main() {
#ifndef DOMJUDGE
  std::ifstream in("sample3.in");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  while(tratar_caso()) { }

#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
  // Descomentar si se trabaja en Windows
  // system("PAUSE");
#endif
  return 0;
}
